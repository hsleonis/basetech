<?php return [
	'caffeine_scale' => array ('10mg-15mg'=>'10mg-15mg', '15mg-20mg'=>'15mg-20mg'),
	'product_status' => array ('1'=>'Active', '0'=>'Inactive'),
	'is_featured' => array ('0'=>'No', '1'=>'Yes'),
	'product_post_titles' =>  array (	
										'Description'=>'Description', 
										'Preparation'=>'Preparation', 
										'Tastings'=>'Tastings'
									),
];
                            